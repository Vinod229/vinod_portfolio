
var myGameArea;
var myGameEnemies = [];
var myBullet = [];
var myGun;
var shoot = false;
var clicked = false;
var enemyInterval = 150;
var myInstructions;
var myScore;
var myGameHeader;
var myLives;
var myHearts;
var play;
var pause;
var myBackground;
var enemyBullets = []; // for level 2


function controlGame(btn){
	if(btn.innerHTML == "Play" || btn.className == "firstlevel"){
		document.getElementById('controlbtn').style.display = "inline-block";
		btn.innerHTML = "Pause";
		myGameArea.start();	
		myGun = new component(145, 430, 'tanker.png', 40, 50, "image");
		myInstructions = new component("20px", "Consolas", "#777", 80, 100, "text");
		myScore = new component("16px", "Arial", "white", 220, 20, "text");
		myLives = new component("16px", "Arial", "white", 25, 20, "text");
		myHearts = new component(10, 6, 'heart.png', 15, 16, "image")
		play = new component(50, 6, 'play.png', 15, 16, "image")
		pause = new component(70, 6, 'pause.png', 15, 16, "image")
		myGameHeader = new component(0, 0, '#0af', 320, 30);
		myBackground = new component(0, 0, "bg.jpeg", 320, 480, "background");
	}else if(btn.innerHTML == "Pause"){
		btn.innerHTML = "Play";
		myGameArea.stop();	
	}
	/*else if (btn.className == "secondlevel") {
		myGameArea.level = 2;
		myGameArea.start();
	}*/
	
}

myGameArea = {
	//canvas : document.createElement('canvas'),
	canvas : document.getElementById('shootingGameCanvas'),
	instructions : document.getElementsByClassName('gameOptions')[0],
	gamePlayButton : document.getElementsByClassName('firstlevel')[0],
	start : function(){
		this.instructions.style.display = 'none';
		this.canvas.width = 320;
		this.canvas.height = 480;
		this.context = this.canvas.getContext('2d');
		this.frameNum = 0;
		this.level = 1;
		this.playing = true;
		//this.shoot = false;
		this.clicked = false;
		this.gameOver = false;
		this.score = 0;
		this.lifeScore = 3;
		//document.body.insertBefore(this.canvas, document.body.childNodes[0]);
		/*window.addEventListener('mousedown', function (e) {
            myGameArea.x = e.pageX - myGameArea.width;
            myGameArea.y = e.pageY - myGameArea.height;
        })
        window.addEventListener('mouseup', function (e) {
        	clicked = false;
            myGameArea.x = false;
            myGameArea.y = false;
        })*/
		window.addEventListener('keydown', function(e){
			myGameArea.key = e.keyCode;
		}, true);
		window.addEventListener('keyup', function(e){
			shoot = false;
			myGameArea.key = false;
			myGun.easeX = 0;
		}, true);
		this.interval = setInterval(updateGameArea, 20);
	},
	
	stop : function(){
		clearInterval(this.interval);
	},
	clear : function(){
		this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
	},
	enemyReach : function(enemy){
		var myBottom = enemy.y + enemy.height;
		if(this.canvas.height - myGun.height <= myBottom){
			return true;
		}
		return false;
	}
}

function component(x, y, color, width, height, type){
	if(type === undefined){
		type = '';
	}else if(type == 'image' || type == 'background'){
	    this.image = new Image();
	    this.image.src = color;
	}
	this.x = x;
	this.y = y;
	this.easeX = 0;
	this.easeY = 0;
	this.color = color;
	this.width = width;
	this.height = height;
	this.type = type;
	ctx = myGameArea.context;
	this.newPos = function(){
		/*this.y += -1;*/
	}
	this.update = function(){
		if(this.type == "text"){
			ctx.font = this.x + " " + this.y;
			ctx.fillStyle = this.color;
			ctx.fillText(this.text, this.width, this.height);
		}else if (this.type == "image" || this.type == "background"){
			ctx.drawImage(this.image, this.x, this.y, this.width, this.height);
		}else{
			ctx.fillStyle = this.color;
			ctx.fillRect(this.x, this.y, this.width, this.height);	
		}
	}
}

function hitEnemy(myBullet){
	var myObstacleTop = myBullet.y;
	var myObstacleRight = myBullet.x + myBullet.width;
	var myObstacleBottom = myBullet.y + myBullet.height;
	var myObstacleLeft = myBullet.x;

	var myEnemyTop;
	var myEnemyRight;
	var myEnemyBottom;
	var myEnemyLeft;

	var instructionElements;
	var secondLevelInstruction = '';

	var hit = false;

	for(e = 0; e < myGameEnemies.length; e++){
		myEnemyTop = myGameEnemies[e].y;
		myEnemyRight = myGameEnemies[e].x + myGameEnemies[e].width;
		myEnemyBottom = myGameEnemies[e].y + myGameEnemies[e].height;
		myEnemyLeft = myGameEnemies[e].x;
		if((myEnemyTop > myObstacleBottom) || (myEnemyLeft > myObstacleRight) || (myEnemyRight < myObstacleLeft) || (myEnemyBottom < myObstacleTop)){
			hit = false;
		}else{
			hit = true;
			hittedEnemy = myGameEnemies.indexOf(myGameEnemies[e]);
			myGameEnemies.splice(hittedEnemy, 1);
			myGameArea.score += 10;
			/*if(myGameArea.score >= 20){
				myGameArea.playing = false;
				myGameArea.instructions.style.display = 'block';
				instructionElements = myGameArea.instructions.children;
				secondLevelInstruction += "<li>You Successfully completed your first level.</li>";
				secondLevelInstruction += "<li>Your score is: "+ myGameArea.score +"</li>";
				instructionElements[1].innerHTML = secondLevelInstruction;
				myGameArea.gamePlayButton.className = "secondlevel";
				myGameArea.gamePlayButton.innerHTML = "Play 2nd Level";
				myGameArea.lifeScore += 3;
				myGameArea.stop();
			}*/
			return hit;
		}
	}
}

// For Level 2
function hitHero(myEnemyBullet){
	var myEnemyBulletTop = myEnemyBullet.y;
	var myEnemyBulletRight = myEnemyBullet.x + myEnemyBullet.width;
	var myEnemyBulletBottom = myEnemyBullet.y + myEnemyBullet.height;
	var myEnemyBulletLeft = myEnemyBullet.x;

	var myHeroTop = myGun.y;
	var myHeroRight = myGun.x + myGun.width;
	var myHeroBottom = myGun.y + myGun.height;
	var myHeroLeft = myGun.x;

	var heroHit = false;

	if((myHeroTop > myEnemyBulletBottom) || (myHeroLeft > myEnemyBulletRight) || (myHeroRight < myEnemyBulletLeft) || (myHeroBottom < myEnemyBulletTop)){
		heroHit = false;
	}else{
		heroHit = true;
		myGun.width = 0;
		myGun.height = 0;
		setTimeout(function(){
			myGun.width = 40;
			myGun.height = 50;
			myGun.x = 140;
		}, 1000);
		return heroHit;
	}
}

function updateGameArea(){
	if(myGameArea.playing){
		myGameArea.clear();
		myBackground.update();
		//myGun.newPos();*/
		
		// Hitting Enemy
		for(b = 0; b < myBullet.length; b++){
			if(hitEnemy(myBullet[b])){
				enemyInterval += -1;
				hittedBullet = myBullet.indexOf(myBullet[b]);
				myBullet.splice(hittedBullet, 1);
			}
		}

		// Hitting Hero For Level 2
		/*if(myGameArea.level == 2){*/
			for(e = 0; e < enemyBullets.length; e++){
				if(hitHero(enemyBullets[e])){
					hittedEnemyBullet = enemyBullets.indexOf(enemyBullets[e]);
					enemyBullets.splice(hittedEnemyBullet, 1);
					myGameArea.lifeScore -= 1;
					checkGameOver(myGameArea.lifeScore);
				}
			}	
		/*}*/
		
		// Moving hero left side
		if(myGameArea.key && (myGameArea.key == 37 || myGameArea.key == 65)){
			if(myGun.x > 0){
				myGun.easeX += 0.1;
				myGun.x = myGun.x + -(1 + myGun.easeX);
			}
		}

		// Moving hero right side
		if(myGameArea.key && (myGameArea.key == 39 || myGameArea.key == 68)){
			if((myGun.x + myGun.width) < myGameArea.canvas.width){
				myGun.easeX += 0.1;
				myGun.x = myGun.x + (1 + myGun.easeX);	
			}
		}

		// Firing a bullet when pressing "F"
		if(myGameArea.key && myGameArea.key == 70){
			if(!shoot && myGun.width == 40 && myGun.height == 50) {
				myBullet.push(new component(myGun.x + 15, myGun.y, 'bullet.png', 10, 30, "image"));	
			}
			shoot = true;
		}

		// Bullets motion.
		for(i = 0; i < myBullet.length; i++){
			myBullet[i].y += -15;
			myBullet[i].update();
		}

		// Enemy Bullets motion. For Level 2
		/*if(myGameArea.level == 2){*/
			for(eb = 0; eb < enemyBullets.length; eb++){
				enemyBullets[eb].y += (1 + ((myGameArea.score/100)/10));
				enemyBullets[eb].update();
			}
		/*}*/

		myGameArea.frameNum += 1;
		if(myGameArea.frameNum == 1 || everyInterval(enemyInterval)){
			for(j = 0; j < 1; j++){
				x = Math.floor(Math.random() * (myGameArea.canvas.width - 50));
				myGameEnemies.push(new component(x, 0, 'enemy.png', 30, 30, 'image'));	
			}
		}

		// For Level 2
		/*if(myGameArea.level == 2){*/
			for(e = 0; e < myGameEnemies.length; e++){
				bulletX = myGameEnemies[e].x + 13;
				bulletY = myGameEnemies[e].y + 25;
				if(myGameArea.frameNum == 100 || everyInterval(Math.floor(Math.random() * 1000) + 100)){
					enemyBullets.push(new component(bulletX, bulletY, 'enemybullet.png', 5, 15, 'image'));
				}
			}
		/*}*/

		// Checking for Lives remaining
		for(i = 0; i < myGameEnemies.length; i++){
				myGameEnemies[i].y += 0.5 + ((myGameArea.score/100)/10);
				if(myGameArea.enemyReach(myGameEnemies[i])){
					myGameEnemy = myGameEnemies.indexOf(myGameEnemies[i]);
					myGameEnemies.splice(myGameEnemy, 1);
					myGameArea.lifeScore -= 1;
					checkGameOver(myGameArea.lifeScore);
				}
			myGameEnemies[i].update();
		}

		// Score board.
		myInstructions.text = 'Press "F" to fire';
		if(myGameArea.gameOver){
			myScore.x = "16px";
			myScore.width = 90;
			myScore.text = 'Game Over Your Score is : ' + myGameArea.score;	
		}else{
			myScore.text = 'Score : ' + myGameArea.score;	
		}
		myLives.text = " " + myGameArea.lifeScore;

		myGun.update();
		//myInstructions.update();
		myGameHeader.update();
		myLives.update();
		myHearts.update();
		myScore.update();
		/*play.update();
		pause.update();*/
	}
}

function everyInterval(interval){
	if((myGameArea.frameNum / interval) % 1 == 0){
		return true;
	}
	return false;
}
function checkGameOver(lifes){
	/*console.log(myGameArea.lifeScore);*/
	if(lifes <= 0){
		myGameArea.gameOver = true;	
		myGameArea.stop();
	}
}